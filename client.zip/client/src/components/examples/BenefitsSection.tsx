import BenefitsSection from '../BenefitsSection';

export default function BenefitsSectionExample() {
  return (
    <div className="min-h-screen bg-background">
      <BenefitsSection />
    </div>
  );
}
