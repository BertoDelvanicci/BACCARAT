import TestimonialsSection from '../TestimonialsSection';

export default function TestimonialsSectionExample() {
  return (
    <div className="min-h-screen bg-background">
      <TestimonialsSection />
    </div>
  );
}
